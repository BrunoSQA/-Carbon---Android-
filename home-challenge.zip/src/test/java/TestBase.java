import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.android.AndroidDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

public class TestBase {
    public static AndroidDriver driver;

    @BeforeSuite
    public void initiate() throws MalformedURLException, InterruptedException {

        File classpathRoot = new File(System.getProperty("user.dir"));
        File appDir = new File(classpathRoot, "/apk/");
        File app = new File(appDir, "paylater-full-debug-v5.5.3-1909091739.apk");

        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability(CapabilityType.BROWSER_NAME, "");
        capabilities.setCapability("deviceName", System.getProperty("deviceName"));
        capabilities.setCapability("platformVersion", System.getProperty("osVersion"));
        capabilities.setCapability("platformName", "Android");
        capabilities.setCapability("noReset", false);
        capabilities.setCapability("fullReset", true);
        capabilities.setCapability("app", app.getAbsolutePath());
        capabilities.setCapability("appPackage", "com.lenddo.mobile.paylater.staging");
        capabilities.setCapability("appActivity", "com.lenddo.mobile.paylater.home.activity.SplashScreenActivity");

        driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

        driver.findElement(By.id("com.lenddo.mobile.paylater.staging:id/carbonUpButton")).click();
        driver.findElement(By.id("com.lenddo.mobile.paylater.staging:id/tutorial_skip")).click();
        driver.findElement(By.id("com.android.packageinstaller:id/permission_allow_button")).click();
    }

    @AfterSuite
    public void tearDown() {
        driver.closeApp();
        driver.quit();
    }

}