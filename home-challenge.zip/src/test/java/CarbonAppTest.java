import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

import static util.TestUtilities.*;


public class CarbonAppTest extends TestBase {

    private String successMessage;

    private final String loginPhoneNumber = "08990001101";
    private final String loginPin = "1234";
    private final String loginOtp = "123456";
    private final String rechargePhoneNumber = "08022220056";

    @Test
    public void loginIsSuccessful_when_usernameAndPasswordAreValid() throws InterruptedException {
        Thread.sleep(1000);

        //Click Sign In Button
        driver.findElement(By.id("com.lenddo.mobile.paylater.staging:id/user_type_existing")).click();

        //Enter Phone Number
        driver.findElement(By.id("com.lenddo.mobile.paylater.staging:id/sign_in_phone")).sendKeys(loginPhoneNumber);

        //Enter PIN
        driver.findElement(By.id("com.lenddo.mobile.paylater.staging:id/sign_in_pin")).sendKeys(loginPin);

        //Click Sign In Button
        driver.findElement(By.id("com.lenddo.mobile.paylater.staging:id/sign_in_next")).click();

        //Wait for progress icon to disappear
        new WebDriverWait(driver, 10)
                .until(ExpectedConditions.invisibilityOf(driver.findElement(By.className("android.widget.ProgressBar"))));

        Thread.sleep(500);

        //Click "Not right now" link
        driver.findElement(By.id("com.lenddo.mobile.paylater.staging:id/tvRightNow")).click();
    }

    //@Test (dependsOnMethods = {"loginIsSuccessful_when_usernameAndPasswordAreValid"})
    public void buyAirtimeIsSuccessful_when_walletBalanceIsSufficient() {
        //Click Buy Airtime Option
        WebElement buyAirtimeLabel = driver.findElement(By.xpath("//android.widget.TextView[@text='Buy Airtime']"));
        new TouchAction(driver).tap(PointOption.point(buyAirtimeLabel.getLocation())).perform();

        //Enter Phone Number
        driver.findElement(By.id("com.lenddo.mobile.paylater.staging:id/edit_text_phone_number")).sendKeys(rechargePhoneNumber);

        //Click #100 Amount Icon
        List<WebElement> airtimeAmountIcons = driver.findElements(By.id("com.lenddo.mobile.paylater.staging:id/layout_amount_background"));
        airtimeAmountIcons.get(0).click();

        //Verify Amount
        String amountFieldText = driver.findElement(By.id("com.lenddo.mobile.paylater.staging:id/edit_text_airtime_price")).getText();
        Assert.assertEquals(amountFieldText, "100");

        //Click Airtel Icon
        List<WebElement> mobileNetworkIcons = driver.findElements(By.id("com.lenddo.mobile.paylater.staging:id/card_mobile_network"));
        mobileNetworkIcons.get(1).click();

        //Click Next Button
        driver.findElement(By.id("com.lenddo.mobile.paylater.staging:id/button_next")).click();

        //Select Pay with Wallet option
        WebElement walletRadioButton = driver.findElement(By.id("com.lenddo.mobile.paylater.staging:id/walletRadioButton"));
        new TouchAction(driver).tap(PointOption.point(walletRadioButton.getLocation())).perform();

        //Verify that Pay with Wallet option is selected
        String isButtonChecked = walletRadioButton.getAttribute("checked");
        Assert.assertEquals(isButtonChecked, "true");

        //Click Confirm Payment Button
        confirmPayment(driver);

        //Confirm details before payment
        String phoneNumber = driver.findElement(By.id("com.lenddo.mobile.paylater.staging:id/text_view_phone_number")).getText();
        Assert.assertEquals(phoneNumber, rechargePhoneNumber);

        String mobileNetwork = driver.findElement(By.id("com.lenddo.mobile.paylater.staging:id/text_view_mobile_network")).getText();
        Assert.assertEquals(mobileNetwork, "Airtel");

        List<WebElement> amountElements = driver.findElements(By.id("com.lenddo.mobile.paylater.staging:id/amount_view_amount"));
        String rechargeAmount = amountElements.get(0).getText();
        Assert.assertEquals(rechargeAmount, "100.00");

        String totalAmount = amountElements.get(1).getText();
        Assert.assertEquals(totalAmount, "100.00");

        String paymentButtonText = driver.findElement(By.id("com.lenddo.mobile.paylater.staging:id/button_text_secure_pay")).getText();
        Assert.assertTrue(paymentButtonText.contains("100.00"));

        //Click Secure Pay Button
        driver.findElement(By.id("com.lenddo.mobile.paylater.staging:id/button_pay")).click();

        enterPinToConfirmPayment(driver, loginOtp);

        //Verify that Airtime Payment was successful
        successMessage = driver.findElement(By.id("com.lenddo.mobile.paylater.staging:id/fontTextView18")).getText();
        Assert.assertEquals(successMessage, "Your airtime purchase was successful!");

        goBackToDashboard(driver);

        clickOkay(driver);
    }

    //@Test //(dependsOnMethods = {"loginIsSuccessful_when_usernameAndPasswordAreValid"})
    public void fundWalletIsSuccessful_when_debitCardDetailsAreValid() throws InterruptedException {
        //Get Initial Balance
        String initialWalletBalance = driver.findElement(By.id("com.lenddo.mobile.paylater.staging:id/walletBalanceView")).getText();
        double initialWalletAmount = Double.parseDouble(initialWalletBalance.substring(1).replace(",", ""));

        //Click Fund Wallet Button
        driver.findElement(By.id("com.lenddo.mobile.paylater.staging:id/fundWalletButton")).click();

        //Click Fund with card
        driver.findElement(By.id("com.lenddo.mobile.paylater.staging:id/fundWalletCard")).click();

        //Enter Amount to fund
        driver.findElement(By.id("com.lenddo.mobile.paylater.staging:id/walletAmountToFund")).sendKeys("1000");

        //Click Proceed Button
        driver.findElement(By.id("com.lenddo.mobile.paylater.staging:id/proceedWalletFunding")).click();

        //Select Pay with Debit/ATM option
        WebElement cardOptionRadioButton = driver.findElement(By.id("com.lenddo.mobile.paylater.staging:id/image_check"));
        new TouchAction(driver).tap(PointOption.point(cardOptionRadioButton.getLocation())).perform();

        Thread.sleep(500);

        //Verify that Pay with Debit/ATM option is selected
        String isButtonChecked = cardOptionRadioButton.getAttribute("checked");
        Assert.assertEquals(isButtonChecked, "true");

        //Click Confirm Payment Button
        confirmPayment(driver);

        //Verify transaction details
        List<WebElement> amountElements = driver.findElements(By.id("com.lenddo.mobile.paylater.staging:id/amount_view_amount"));
        String fundAmount = amountElements.get(0).getText();
        Assert.assertEquals(fundAmount, "1,000");

        String serviceCharge = amountElements.get(1).getText();
        Assert.assertEquals(serviceCharge, "10");

        String totalAmount = amountElements.get(2).getText();
        Assert.assertEquals(totalAmount, "1,010");

        String paymentButtonText = driver.findElement(By.id("com.lenddo.mobile.paylater.staging:id/button_text_secure_pay")).getText();
        Assert.assertTrue(paymentButtonText.contains("1,010"));

        //Click Secure Pay Button
        driver.findElement(By.id("com.lenddo.mobile.paylater.staging:id/secure_pay_button")).click();

        enterPinToConfirmPayment(driver, loginOtp);

        String amountCredited = driver.findElement(By.id("com.lenddo.mobile.paylater.staging:id/value_amount")).getText();
        Assert.assertEquals(amountCredited.substring(1), "1,000.00");

        goBackToDashboard(driver);

        clickOkay(driver);

        //Wait for 2secs for balance to be updated
        Thread.sleep(2000);

        //Verify Updated Balance
        String updatedWalletBalance = driver.findElement(By.id("com.lenddo.mobile.paylater.staging:id/walletBalanceView")).getText();
        double updatedWalletAmount = Double.parseDouble(updatedWalletBalance.substring(1).replace(",", ""));
        Assert.assertEquals(updatedWalletAmount, initialWalletAmount + 1000.00);
    }

    @Test //(dependsOnMethods = {"fundWalletIsSuccessful_when_debitCardDetailsAreValid"})
    public void transactionHistoryShouldBeFiltered_when_filterOptionIsApplied() throws InterruptedException {
        //Click Transactions Button
        driver.findElement(By.id("com.lenddo.mobile.paylater.staging:id/viewWalletTransactionsButton")).click();

        new WebDriverWait(driver, 10).until(ExpectedConditions
                .invisibilityOfElementLocated(By.id("com.lenddo.mobile.paylater.staging:id/centreProgressBar")));

        //Click Incoming Tab
        driver.findElement(By.xpath("//android.support.v7.app.ActionBar$Tab[@content-desc='Incoming']")).click();

        new WebDriverWait(driver, 10).until(ExpectedConditions
                .invisibilityOfElementLocated(By.id("com.lenddo.mobile.paylater.staging:id/centreProgressBar")));

        //Dropdown Filter Option
        driver.findElement(By.id("com.lenddo.mobile.paylater.staging:id/transactionTypeSpinner")).click();

        //Select Wallet
        driver.findElement(By.xpath("//android.widget.TextView[@text='Wallet']")).click();

        Thread.sleep(10000);
    }
}
