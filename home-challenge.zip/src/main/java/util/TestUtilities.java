package util;

import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TestUtilities {
    public static void confirmPayment(AndroidDriver driver) {
        driver.findElement(By.id("com.lenddo.mobile.paylater.staging:id/button_confirm_payment")).click();
    }

    public static void enterPinToConfirmPayment(AndroidDriver driver, String otp) {
        new WebDriverWait(driver, 10)
                .until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.TextView[@text='Enter your Carbon PIN']")));

        driver.getKeyboard().sendKeys(otp);
    }

    public static void goBackToDashboard(AndroidDriver driver) {
        driver.findElement(By.id("com.lenddo.mobile.paylater.staging:id/success_home_button")).click();
    }

    public static void clickOkay(AndroidDriver driver) {
        try {
            driver.findElement(By.id("com.lenddo.mobile.paylater.staging:id/okayButton")).click();
        }
        catch (NoSuchElementException e) {}
    }
}
