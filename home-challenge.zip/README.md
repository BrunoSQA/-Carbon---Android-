# Home Challenge - Carbon App
Appium Test Suite for the **home-challenge task 6**

## The Setup
- Java 8+ jdk must be [installed](http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html)  
- Maven must be [installed](https://maven.apache.org/download.cgi) 
- Appium 1.15.0 must be [installed](http://appium.io/)
- Carbon App **must** have been installed on Android Device / Emulator and Test Phone Number **must** have been verified successfully

## Running the Test Suite
From the project root folder, run `mvn test -DdeviceName=<your_device_name> -DosVersion=<your_device_os_version`>

######For example:
`mvn test -DdeviceName=emulator-5554 -DosVersion=8.1`

## Viewing Test Report
1. Go to test report location: `<project_root_folder>\target\surefire-reports`
2. Open `CarbonAppTestReport.html` in a web browser
